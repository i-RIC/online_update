<?xml version="1.0" encoding="UTF-8"?>
<TS version="2.0" language="ja_JP">
    <!--これは iRIC で使用する辞書ファイルです。
<translation> と </translation> の間に、翻訳後の文字列を追記してください。
-->
    <context>
        <message>
            <source>2D-XY Grid Generator</source>
            <translation>平面2次元直交格子生成ツール</translation>
        </message>
        <message>
            <source>Channel shape</source>
            <translation>流路形状</translation>
        </message>
        <message>
            <source>Channel Length(m)</source>
            <translation>流路長(m)</translation>
        </message>
        <message>
            <source>Numbers of Node in X-direction</source>
            <translation>X方向(流下方向)の格子数</translation>
        </message>
        <message>
            <source>Channel Width(m)</source>
            <translation>流路幅(m)</translation>
        </message>
        <message>
            <source>Numbers of Nodes in Y-direction</source>
            <translation>Y方向(横断方向)の格子数</translation>
        </message>
        <message>
            <source>Bed Slope</source>
            <translation>流路勾配</translation>
        </message>
        <message>
            <source>Bed Elevation of Downstream End</source>
            <translation>下流端の河床高(m)</translation>
        </message>
        <message>
            <source>IMax * JMax must be smaller than 100,000.</source>
            <translation></translation>
        </message>
    </context>
</TS>
