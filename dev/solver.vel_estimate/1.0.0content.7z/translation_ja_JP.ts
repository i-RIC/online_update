<?xml version="1.0" encoding="UTF-8"?>
<TS version="2.0" language="ja_JP">
    <context>
        <message>
            <source>Velocity estimation tool</source>
            <translation>Velocity estimation tool</translation>
        </message>
        <message>
            <source>Basic Setting</source>
            <translation>基本設定</translation>
        </message>
        <message>
            <source>Manning's Roughness</source>
            <translation>マニングの粗度係数</translation>
        </message>
        <message>
            <source>Elevation</source>
            <translation>標高</translation>
        </message>
        <message>
            <source>Water Surface Elevation</source>
            <translation>水位</translation>
        </message>
    </context>
</TS>
