About private folders for registering your private solvers and grid generators

"solvers" folder and "gridcreators" folder are used to store the official
solvers installed by iRIC installer.

To avoid confusion, please deploy your private solvers and grid generators
under "solvers" folder and "grid creators" folder under "private" folder.
