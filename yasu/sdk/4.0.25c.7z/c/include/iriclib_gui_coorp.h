#ifndef IRICLIB_GUI_COORP_H
#define IRICLIB_GUI_COORP_H

#include "iriclib_global.h"

#ifdef __cplusplus
extern "C" {
#endif

int IRICLIBDLL iRIC_Check_Cancel();
int IRICLIBDLL cg_iRIC_Check_Update(int fid);

#ifdef __cplusplus
}
#endif

#endif // IRICLIB_GUI_COORP_H
