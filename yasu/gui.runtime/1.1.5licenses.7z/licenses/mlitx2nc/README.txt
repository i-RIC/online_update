This folder contains the LIENSE file file bundled with mlitx2nc.exe.
