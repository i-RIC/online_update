This folder contains the README file bundled with ffmpeg.exe (README_ffmpeg.txt).
ffmpeg.exe is built linking with many libraries, and the licenses for each libraries 
are contained in licenses folder.
